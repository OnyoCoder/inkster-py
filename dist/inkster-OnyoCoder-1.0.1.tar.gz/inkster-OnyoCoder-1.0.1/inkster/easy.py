#Imports
import random
# Variables
# Normal
class Normal:

    def hello(self, name):
        print("Hello " + name + ".")

    def log(self, logged):
        return logged

Normal = Normal()
